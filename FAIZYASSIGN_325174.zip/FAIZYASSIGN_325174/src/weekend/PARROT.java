package weekend;

public class PARROT extends BIRD{
	int leng;
	int mass;
	
	public void i() {
		System.out.println("Parrot imitate sounds ");
	}
	

	public void s() {
		System.out.println("Parrot scream noise");
	}
	
	
		
	public PARROT(int leng, int mass, int age, String color, String food, String gender, String name, int nol) {
		// TODO Auto-generated constructor stub
		this.leng=leng;
		this.mass=mass;
	    this.age=age;
		this.color=color;
		this.food=food;
		this.gender=gender;
		this.name=name;
		this.nol=nol;
	}


	public void display() {
		System.out.println(" Name: "+this.name +" No of legs: " +this.nol + " Skin color: "+ this.color + " Food: " + this.food 
							+ " Gender: " + this.gender + " Age: " + this.age );
		
		System.out.println(" Length of trunk : "+ this.leng + " Length of tusks: " + this.mass);
	}
}
