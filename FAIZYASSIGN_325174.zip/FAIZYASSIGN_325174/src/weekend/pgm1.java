package weekend;
//storing even no from 10 to 30 in array_list.

import java.util.ArrayList;

public class pgm1 {
	public static void main(String[] args) {
		 ArrayList<Integer> al = new ArrayList<Integer>(); //creating a array_list object al
		 for(int i=10;i<=30;i++) {
			 if(i%2==0) {
				 al.add(i);
			 }
		 }
		 System.out.println(al);
	}
}

