package weekend;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int arr[]=new int[5];
		int temp,rem,l=500,sum=0,c=0;
		System.out.println("armstrong no");
		for(int i=1;i<=l;i++)
		{
			temp=i;
			while(temp!=0)
			{
				rem=temp%10;
				sum=sum+(rem*rem*rem);
				temp=temp/10;
			}
				if(sum==i)
				{
					arr[c]=i;
					c++;
					}
				sum=0;
			
		}
		for(int v=0;v<5;v++)
		{
			System.out.println(arr[v]);
		}
		
	}

}