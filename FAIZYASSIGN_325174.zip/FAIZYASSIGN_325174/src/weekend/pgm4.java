package weekend;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		student s1=new student(1,"Bruce",98,97);
		student s2=new student(2,"Rachel",92,87);
		student s3=new student(3,"Joker",45,43);
		s1.average();
		s2.average();
		s3.average();
		if(s1.avg>65) {
		  System.out.println("Name : " + s1.name + " Roll No: " + s1.rollno + " Java Marks: " + s1.java + " Selenium Marks: "+ s1.selenium );
		}
		if(s2.avg>65) {
		System.out.println("Name : " + s2.name + " Roll No: " + s2.rollno + " Java Marks: " + s2.java + " Selenium Marks: "+ s2.selenium );
		}
		if(s3.avg>65) {
		System.out.println("Name : " + s3.name + " Roll No: " + s3.rollno + " Java Marks: " + s3.java + " Selenium Marks: "+ s3.selenium );	
		}
		
	}

}
