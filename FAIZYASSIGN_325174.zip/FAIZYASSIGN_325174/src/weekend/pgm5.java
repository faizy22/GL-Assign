package weekend;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PARROT p1 = new PARROT(98,567,80,"Green","fruit","F","kakapo",2);
		PARROT p2 = new PARROT(62,97,40,"Red","seed","M","Macaw",2);
		PARROT p3 = new PARROT(8,12,20,"Pink","insect","F","Pygmy",2);
		OWL o1 = new OWL(657,60,3,"Yellow","squirrel","F","Barn",2);
		OWL o2= new OWL(70,980,4,"Grey","insect","M","Eurasian",2);
		
		p1.display();
		p1.eats();
		p1.flys();
		p2.display();
		p2.i();
		p2.flys();
		p3.display();
		p3.eats();
		p3.s();
		
		o1.display();
		o1.eats();
		o1.rotatesneck();
		o2.display();
		o2.hunts();
		
	}
}
