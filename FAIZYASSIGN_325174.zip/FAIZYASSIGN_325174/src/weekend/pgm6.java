package weekend;

import java.util.ArrayList;

public class pgm6{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<product> al = new ArrayList<product>();
		operation op1 = new operation();		
		al=op1.read_excel();		
		op1.write_excel(al);
	}

}
