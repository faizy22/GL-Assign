//
package DAY1;
import java.util.Scanner;

public class pgm1 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int n,c,j,d=0;
		Scanner i= new Scanner(System.in);
		n=i.nextInt();
		for(j=1;j<=n;j++)
		{
		if(n%j==0)
			d++;
		}
			
			if(d==2)
				System.out.println("the no is prime");
			else 
				System.out.println("the no is not prime");	
	}

}
