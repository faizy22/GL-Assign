package DAY1;

import java.util.Scanner;

public class pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner i= new Scanner(System.in);
		char ch=i.next().charAt(0);
		if(ch=='a'|| ch=='e'|| ch=='i'|| ch=='o'|| ch=='u'|| ch=='A'|| ch=='E'|| ch=='I'|| ch=='O'|| ch=='U')
			System.out.println("CH IS VOWEL");
		else 
			System.out.println("ch is not consonant");
	}

}
