package DAY1;

import java.util.Scanner;

public class pgm12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float marks;
		float a,b,c;
		Scanner i= new Scanner(System.in);
		a=i.nextFloat();
		b=i.nextFloat();
		c=i.nextFloat();
		
		marks=(a+b+c)/3;
		System.out.println("mark"+marks);
		
		if(marks>=60) {
			System.out.println("First class");

		}
		else if(marks>=50 && marks<60) {
		System.out.println("second class");
	}
	else if (marks>=35 && marks<60) {
	System.out.println("pass class");
}
else {
	System.out.println("fail");
}




}

}
