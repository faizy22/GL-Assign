package DAY1;
import java.util.Scanner;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner in= new Scanner(System.in);
		int n,np;
		n=in.nextInt();//in is a object and the object is stored in n.
		np=n;   //n is stored in np so that we can do it later on
		int remainder,reversedno=0,i;
		while(n!=0) {
			remainder=n%10;
			reversedno=reversedno*10+remainder;
			n=n/10;
		}
		System.out.println(reversedno);
		if(np==reversedno)
		{
			System.out.println("pallindronme");
		}
		else
		{
			System.out.println("not a pallindrome");
		
		}
		
	}



}


