package DAY1;

import java.util.Scanner;

public class pgm9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner i= new Scanner(System.in);
		int a=i.nextInt();
		int b=i.nextInt();

		if(a>b)
			System.out.println("a is greater");
		else if(a<b)
			System.out.println("a is less than b");
		else
			System.out.println("a is equal to b");


	}

}
