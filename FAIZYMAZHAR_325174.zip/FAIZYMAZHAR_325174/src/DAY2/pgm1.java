package DAY2;

import java.util.Scanner;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner i= new Scanner(System.in);
		int n=i.nextInt();
		switch(n)
		{
			case 2:
			System.out.println("two");
			break;
			 
			case 4:
			System.out.println("four");
			break;
			
			case 9:
			System.out.println("nine");
			break;
			default:
			System.out.println("no match");
		}
		System.out.println("out of switch");
		i.close();
	}
		
	}

