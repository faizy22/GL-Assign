package DAY2;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;
		for(i=1;i<=30;i++)
		{
			if(i%3==0 && i%5!=0)
				System.out.println(i);
			
		}

	}

}
