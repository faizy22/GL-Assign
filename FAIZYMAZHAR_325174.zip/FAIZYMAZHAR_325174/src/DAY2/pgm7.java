package DAY2;

import java.util.Scanner;

public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner i= new Scanner(System.in);
		int a=i.nextInt();
		int sum=0;
		while(a!=0) {
			int z=a%10;
			if(z>5)
			{
				sum=sum+z;
			}
			a=a/10;
		}
		System.out.println(sum);
		
		
	}

}
