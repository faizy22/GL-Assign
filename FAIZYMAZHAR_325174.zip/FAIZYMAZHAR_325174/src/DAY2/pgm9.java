package DAY2; 

public class pgm9{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j=4;
		for(i=5;i<=9;i++)
		{
			{
				System.out.println(i+"*"+j+"="+(i*j));
				j=j+2;
			}
		}

	}

}
