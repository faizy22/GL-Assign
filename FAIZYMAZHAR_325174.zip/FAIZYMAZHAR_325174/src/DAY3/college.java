package DAY3;

public class college {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			
				student rakesh=new student();
				rakesh.rollno=73;
				rakesh.name="rakesh";
				rakesh.m1=83;
				rakesh.m2=91;
				rakesh.average();
				System.out.println(rakesh.avg);
				System.out.println(rakesh.rollno);
				System.out.println(rakesh.name);
				System.out.println(rakesh.m1);
				System.out.println(rakesh.m2);
		
				System.out.println();
				student priya=new student();
				priya.rollno=70;
				priya.name="priya";
				priya.m1=80;
				priya.m2=90;
				priya.average();
				System.out.println(priya.avg);
				System.out.println(priya.rollno);
				System.out.println(priya.name);
				System.out.println(priya.m1);
				System.out.println(priya.m2);
			}
		
	}
