package DAY3;
//use the function to check whether its even or odd

public class pgm2 {
	static int iseven(int num)
	{
		if(num%2==0)
			return num;
		else 
			return 0;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		int num[]= {21,34,91,59,16,25,29,74,49,82};
		for(int i=0;i<=9;i++)
		{
			sum=sum+iseven(num[i]);
		}
			System.out.println(sum);
		}

	}


