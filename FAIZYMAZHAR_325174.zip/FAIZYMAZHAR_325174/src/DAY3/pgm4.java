package DAY3;

public class pgm4 {
public static void maxele(int r, int[][] arr) {
int i = 0;
int max = 0;
int[] result = new int[r];
while (i<r) {
for (int j = 0; j < arr[i].length; j++) {
if (arr[i][j] > max) {
max = arr[i][j];
}
}
result[i] = max;
max =0;
i++;

}
for (int k =0; k<result.length;k++) {
System.out.println(result[k]);
}

}

public static void main(String[] args) {
int arr[][]= {{97,85,90,92},{77,80,89,98},{70,75,84,99}};

maxele(3, arr);
}
}
