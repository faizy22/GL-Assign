package DAY3;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		String s1="I love globallogic";
		int c=0,p=0;
		while(p!=-1)//if -1 comes then it means the value is not present.
		{
			p=s1.indexOf(" ",p+1);
			c++;
		}
		c=c-1;
		
		   
			System.out.println("number of spaces:"+c);
		
	}

}
