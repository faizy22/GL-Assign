package DAY4;

public class calculater1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		calc_v1 calc= new calc_v1();
		int sum = calc.add(5, 10);
		System.out.println("First sum: "+sum);
		
		float s=calc.add(2,3,4.1f);
		System.out.println("Second sum: "+s);
	}

}
