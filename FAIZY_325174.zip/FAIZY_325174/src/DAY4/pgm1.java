package DAY4;

public class pgm1 {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			int cm=4,dm=1;
			for(int r=1;r<=3;r++) {
				
				for(int c=1;c<=cm;c++) {
					System.out.print(" ");
				}
				for(int d=1;d<=dm;d++) {
					System.out.print("1 ");
				}
				cm=cm-2;
				dm++;
				System.out.println();
			}
		}

	}
