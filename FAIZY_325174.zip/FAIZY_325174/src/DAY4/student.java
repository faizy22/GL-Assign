package DAY4;

public class student {
	int rollno;
	String name;
	int m1;
	int m2;
	float avg;
	public student(int rollno, String name, int m1, int m2) {
		this.rollno=rollno;
		this.name=name;
		this.m1=m1;
		this.m2=m2;
	}
	public float average(int m1,int m2) {
		avg=(m1+m2)/2.0f;
		return avg;
	}
	public void display(String name, int rollno) {
		System.out.println("Name: "+name);
		System.out.println("Roll No: "+rollno);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		student s1=new student(101,"Raj",91,95);
		
		s1.display(s1.name, s1.rollno);
		
		System.out.println(s1.average(s1.m1,s1.m2));
	}

}
