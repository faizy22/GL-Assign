package DAY5;

public class excel_main {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r1;
		excel ex=new excel();
		student s1=ex.cellop();
		s1.average();
		ex.write_excel(s1);
		
		
         
	}

}
