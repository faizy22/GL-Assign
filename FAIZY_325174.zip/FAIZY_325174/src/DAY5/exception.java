package DAY5;

public class exception {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {

	 		int a[]= {1,2,3};
	 		System.out.println(a[3]);
	 		
	 		int n=10,c=0,p;
	         p=n/c;
	         System.out.println(p);
	         
		}
		
		catch (ArithmeticException e)
		{
			System.out.println("in aritghmetuic exp");
		}
		
		catch(ArrayIndexOutOfBoundsException ep)
		{
		   System.out.println("in array out of bound exp");
		}
		
			catch(Exception ee)
			{
						
					}
		
	}
	}


