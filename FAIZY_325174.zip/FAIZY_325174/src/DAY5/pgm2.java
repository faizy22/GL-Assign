package DAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s,t;
		
		try {
			File f=new File("C:\\Users\\faizy.mazhar\\Desktop\\hello\\Book1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(0);
			XSSFCell c=r.getCell(0);
			XSSFRow r1=sh.getRow(2);
			XSSFCell c1=r1.getCell(0);
			s=c.getStringCellValue();
			t=c1.getStringCellValue();
			System.out.println(s+" "+t);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
