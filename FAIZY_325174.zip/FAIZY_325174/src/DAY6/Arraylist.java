package DAY6;
//array list using string

import java.util.ArrayList;

public class Arraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList al=new ArrayList<String>();
		al.add("hello");
		al.add("world");
		al.add("india");
		
		System.out.println("before insertion"+al);
		
	 al.add(2,"usa");
		
		



}
}
