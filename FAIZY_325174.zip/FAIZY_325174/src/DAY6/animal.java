package DAY6;

public class animal {
	int nol;
	String color;
	String food;
	String name;
	String gender;
	String age;
   public void eats()
   {
	   System.out.println("the animal eats :" +food);
	   
   }
   
   public void walks()
   {
	   System.out.println("the animal walks");
	   
   }
   
   public void drink()
   {
	   System.out.println("the animal drink");
	   
   }
   
  
   public void display()
   {
	   System.out.println("no of legs :" +this.nol
			              +"skin color :" +this.color 
			              +"food :" +this.food
			              +"name :"+this.name
			              +"gender:"+this.gender
			              +"age :"+this.age);
   }}
   
   
   