package DAY6;

public class elephant extends animal {
	int lotrunk;
	int lotusks;
	int qotrunk;
	public void swim()
	{
		System.out.println("elephant swim");
	}
	public void breaktree()
	{
		System.out.println("elephant can break tree");
	}
	
	
	
	public void display_elephant(int lotrunk,int lotusks,int qotrunk)
	{
		
		System.out.println("length of trunk:" +lotrunk
				           + " length of tusks: " +lotusks 
				           + " quality of trunk: " +qotrunk 
				           + " No of legs: " +nol 
				           + " Skin color: "+color 
				           + " Food: " + food  
				           + " Name: "+name 
				           + " Gender: " + gender 
				           + " Age: " + age );
	
	
	}
	

}
