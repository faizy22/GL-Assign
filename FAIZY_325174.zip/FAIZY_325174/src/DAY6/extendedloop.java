package DAY6;

public class extendedloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str[]= {"Global","Logic"};
		for(String s:str)
		{
			System.out.println(s);
		}

	}
	

}
