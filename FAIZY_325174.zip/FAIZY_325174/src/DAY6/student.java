package DAY6;
//array list using student object 
public class student {

	
	String name ;
	public int rollno;
	int sel;
	int jav;
	float avg;
	
	public float average()
	{
		avg=(sel+jav)/2.0f;
		return avg;
	}
	public student(String name,int rollno,int sel,int java)
	{
		this.name=name;
		this.rollno=rollno;
		this.sel=sel;
		this.jav=java;
		this.average();
		
	}
	
}
