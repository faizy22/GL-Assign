package DAY6;
public class test_animal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		tiger t1=new tiger();
		tiger t2=new tiger();
		
		elephant e1=new elephant();
		elephant e2=new elephant();
		
		e1.age="21";
		e1.color="black";
		e1.food="banana-leaf";
		e1.gender="male";
		e1.nol=4;
		
		e1.display_elephant(44,45,9);
	
		
		
		e2.age="22";
		e2.color="white";
		e2.food="mango-leaf";
		e2.gender="female";
		e1.display_elephant(44,45,9);


		t1.age="24";
		t1.color="black";
		t1.food="deer";
		t1.gender="male";
        t1.display_tiger(1,2,3);
		
		t2.age="22";
		t2.color="white";
		t2.food="mango-leaf";
		t2.gender="female";
		 t1.display_tiger(4,5,6);
		
		
		
		
		
		
		
		
	}

}
