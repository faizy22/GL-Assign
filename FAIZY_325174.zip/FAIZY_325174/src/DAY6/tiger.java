package DAY6;


public class tiger extends animal{
	int lenghtofteeth;
	int lenghtofclaw;
	int speed;
	
	public void roar() {
		System.out.println("Tiger Roars");
	}
	

	public void climb() {
		System.out.println("Tiger climbs tree");
	}
	
	public void hunt() {
		System.out.println("Tiger do hunting");
	}
	
	
	public void display_tiger(int lengthofteeth,int lengthofclaw,int speed) {
		System.out.println(" No of legs: " +this.nol 
				         + " Skin color: "+ this.color 
				         + " Food: " + this.food 
				         + " Name: "+this.name 
						 + " Gender: " + this.gender 
						 + " Age: " + this.age );	
		
	}

}
