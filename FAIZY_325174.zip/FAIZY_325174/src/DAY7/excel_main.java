package DAY7;

import java.util.ArrayList;


public class excel_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		
		excel_operation1 ex= new excel_operation1();  
		ArrayList<student> std2=new ArrayList<student>();
		
		
		std2=ex.read_excel(); 
		ex.write_excel(std2);
	

}}
