package DAY7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_operation1 {
	public void write_excel(ArrayList<student> al_std1)
	{
		int row=1;
		try {
			File f=new File("C:\\Users\\faizy.mazhar\\Desktop\\Book4.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			for(student s1:al_std1)
			{
			XSSFRow r=sh.getRow(row);
			XSSFCell c=r.createCell(4);
			c.setCellValue((double)s1.avg);
			row++;
			}
			FileOutputStream fos=new FileOutputStream(f);//necessary for write excel
			wb.write(fos);                               //necessary for write excel
			
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
	}
	public ArrayList<student> read_excel() {  //changed here n(2)
		//student s=new student();
		ArrayList<student> std_al =new ArrayList<student>();
		
	  
	try {
		File f=new File("C:\\Users\\faizy.mazhar\\Desktop\\Book4.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");//using wb to get sheet
		
		int firstrow=sh.getFirstRowNum();
		int lastrow=sh.getLastRowNum();
	   int nor=lastrow-firstrow;
	   
		for(int i=1;i<=nor;i++)    
		{
		student s=new student();
		
		XSSFRow r=sh.getRow(i); //using sheet to get row       changed here 1 to n
		XSSFCell c=r.getCell(0);  //using row to get the cell
		s.rollno=(int)c.getNumericCellValue();
		
		XSSFCell c1=r.getCell(1);
		s.name=c1.getStringCellValue();
		
		XSSFCell c2=r.getCell(2);
		s.java=(int)c2.getNumericCellValue();
		
		XSSFCell c3=r.getCell(3);
		s.selenium=(int)c3.getNumericCellValue();
		System.out.println(s);
		
		s.average();
		std_al.add(s);
		}
		
	} catch (FileNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (IOException e2) {
		// TODO Auto-generated catch block
		e2.printStackTrace();
	}
	return std_al; //returnig s object
}

}
