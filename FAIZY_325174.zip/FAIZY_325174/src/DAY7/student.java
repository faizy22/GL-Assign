package DAY7;

public class student {


	public int rollno;
	public String name;
	public int java;
	public int selenium;
	public float avg;
	
	public float average()
	{
		 avg=(java+selenium)/2.0f;
		 return avg;
	}
}
