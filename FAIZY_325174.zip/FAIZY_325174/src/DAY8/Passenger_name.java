package DAY8;

public class Passenger_name {
	public int Sl_no;
	public String Passenger_name;
	public String From;
	public String To;
	public int rate;
	public int nos;
	public int Total;
	
	public int passenger()
	{
		Total=rate*nos;
		return Total;
		
	}
}
