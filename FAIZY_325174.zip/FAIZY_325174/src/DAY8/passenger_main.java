package DAY8;

import java.util.ArrayList;


public class passenger_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		passenger_opeartion p= new passenger_opeartion();  
		ArrayList<Passenger_name> psng2=new ArrayList<Passenger_name>();
		
		
		psng2=p.read_excel(); 
		p.write_excel(psng2);
	

}}

