package DAY8;

	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.util.ArrayList;

	import org.apache.poi.xssf.usermodel.XSSFCell;
	import org.apache.poi.xssf.usermodel.XSSFRow;
	import org.apache.poi.xssf.usermodel.XSSFSheet;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;

	public class passenger_opeartion{
		public void write_excel(ArrayList<Passenger_name> al_std1)
		{
			int row=1;
			try {
				File f=new File("C:\\Users\\faizy.mazhar\\Desktop\\Book1.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				for(Passenger_name s1:al_std1)
				{
				XSSFRow r=sh.getRow(row);
				XSSFCell c=r.createCell(6);
				c.setCellValue(s1.Total);
				row++;
				}
				FileOutputStream fos=new FileOutputStream(f);
				wb.write(fos);                              
				
				
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
		}
		public ArrayList<Passenger_name> read_excel() {
			//passenger_name p=new passenger_name();
			ArrayList<Passenger_name> psng_al =new ArrayList<Passenger_name>();
			
		  
		try {
			File f=new File("C:\\Users\\faizy.mazhar\\Desktop\\Book1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
			
			int firstrow=sh.getFirstRowNum();
			int lastrow=sh.getLastRowNum();
		    int nor=lastrow-firstrow;
		   
			for(int i=1;i<=nor;i++)    
			{
				Passenger_name p=new Passenger_name();
			
			XSSFRow r=sh.getRow(i); //using sheet to get row       changed here 1 to n
			XSSFCell c=r.getCell(0);  //using row to get the cell
			p.Sl_no=(int)c.getNumericCellValue();
			
			XSSFCell c1=r.getCell(1);
			p.Passenger_name=c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(2);
			p.From=c2.getStringCellValue();
			

			XSSFCell c3=r.getCell(3);
			p.To=c3.getStringCellValue();
			
			
			XSSFCell c4=r.getCell(4);  //using row to get the cell
			p.rate=(int)c4.getNumericCellValue();
			
			XSSFCell c5=r.getCell(5);  //using row to get the cell
			p.nos=(int)c5.getNumericCellValue();
			
			System.out.println(p);
			
			p.passenger();
			psng_al.add(p);
			}
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		return psng_al;
	}

	}


