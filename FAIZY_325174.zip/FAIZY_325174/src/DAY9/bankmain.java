package DAY9;

public class bankmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		bank b=new citibank();
		System.out.println("citibank roi"+b.roi());
	      b=new yes();
		System.out.println("yesbank roi"+b.roi());
		}

}
