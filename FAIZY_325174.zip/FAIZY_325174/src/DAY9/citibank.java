package DAY9;

	public class citibank extends bank{
		public float roi()
		{
			return 8.4f;
		}
	}


