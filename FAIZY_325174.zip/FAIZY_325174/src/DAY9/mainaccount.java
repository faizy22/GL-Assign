package DAY9;
//ENCAPSULATION USE OF GET AND SET

public class mainaccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	  test_account a=new test_account();
	  a.setAcc_no(2445);
	  a.setAcc_balance(100);
	  System.out.println("acc_no:"+a.getAcc_no()+ "acc_balance:"+a.getAcc_balance());
		
	}

}
