package DAY9;

public class test_account {
	private int acc_no;
	private int acc_balance;
	public int getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(int acc_no) {    //READ ACCESS 
		this.acc_no = acc_no;
	}
	public int getAcc_balance() {     //WRITE ACCESS
		return acc_balance; 
	}
	public void setAcc_balance(int acc_balance) {
		this.acc_balance = acc_balance;
	}
	
	

}
