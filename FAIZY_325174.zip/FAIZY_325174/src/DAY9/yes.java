package DAY9;

	public class yes extends bank{
		public float roi()
		{
			return 8.8f;
		}
	}


