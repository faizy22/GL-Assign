$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("a.feature");
formatter.feature({
  "line": 1,
  "name": "AUT Login",
  "description": "",
  "id": "aut-login",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 10,
  "name": "To verify login for Invalid data",
  "description": "",
  "id": "aut-login;to-verify-login-for-invalid-data",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 9,
      "name": "@ROUND2"
    }
  ]
});
formatter.step({
  "line": 11,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 12,
  "name": "User enters invalid login details",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "Login is not successful",
  "keyword": "Then "
});
formatter.match({
  "location": "test1.login_page_is_displayed()"
});
formatter.result({
  "duration": 10051282400,
  "status": "passed"
});
formatter.match({
  "location": "test2.user_enters_invalid_login_details()"
});
formatter.result({
  "duration": 1183738900,
  "status": "passed"
});
formatter.match({
  "location": "test2.login_is_not_successful()"
});
formatter.result({
  "duration": 44380000,
  "error_message": "java.lang.AssertionError: The following asserts failed:\n\texpected [Log in] but found [Log out]\r\n\tat org.testng.asserts.SoftAssert.assertAll(SoftAssert.java:43)\r\n\tat STEP_DEF.test2.login_is_not_successful(test2.java:31)\r\n\tat ✽.Then Login is not successful(a.feature:13)\r\n",
  "status": "failed"
});
});