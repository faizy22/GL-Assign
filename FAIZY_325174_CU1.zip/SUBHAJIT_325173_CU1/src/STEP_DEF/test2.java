package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test2 {
	WebDriver dr;
	@When("^User enters invalid login details$")
	public void user_enters_invalid_login_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		dr=test1.dr;
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("subhajit.chikky@gmail.com");
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("chikky19997");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		
	}

	@Then("^Login is not successful$")
	public void login_is_not_successful() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String s="Log out";
		String e=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).getText();
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(s, e);
		sa.assertAll();
		System.out.println("Login page is not displayed");
		
		
	    
	}
}
