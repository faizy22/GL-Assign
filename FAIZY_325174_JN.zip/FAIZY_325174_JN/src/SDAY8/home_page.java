package SDAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class home_page {
	WebDriver dr;
	String base_xp="//div[@class='inventory_item'][";
	By xname,xprice,xbtn;
	public home_page(WebDriver dr) {
		this.dr=dr;
	}
	public void search() {
		dr.findElement(By.xpath("//input[@placeholder='Search for products, brands and more']")).sendKeys("wireless earphones");
	
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("dsjhhdj");
		dr.findElement(By.xpath("//body/div[@id='container']/div/div[@class='_3ybBIU']/div[@class='_1tz-RS']/div[@class='_3pNZKl']/div[@class='Y5-ZPI']/form[@class='_1WMLwI header-form-search']/div[@class='col-12-12 _2tVp4j']/button[@class='vh79eN']/*[1]")).click();
		//System.out.println(s);
	}
	
	public String get_product_name(int n) {
		xname=By.xpath(base_xp+n+"]//div[@class='inventory_item_name']");
		String pname=dr.findElement(xname).getText();
		return pname;
	}
	public void add_to_cart(int n) {
		xbtn=By.xpath(base_xp+n+"]//button");
		dr.findElement(xbtn).click();
	}
	public void click_cart() {
		dr.findElement(By.xpath("//div[@class='shopping_cart_container']")).click();
		////*[@id="shopping_cart_container"]/a/svg/path
	}
}
