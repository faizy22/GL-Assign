package SDAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class login_page {
	WebDriver dr;
	public login_page(WebDriver dr2) {
		// TODO Auto-generated constructor stub
		this.dr=dr2;
	}
	public void do_login(String email, String pass) {
		// TODO Auto-generated method stub
		dr.findElement(By.xpath("//*[@id=\"user-name\"]")).sendKeys(email);
		dr.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys(pass);
		dr.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]")).click();
	}

}
