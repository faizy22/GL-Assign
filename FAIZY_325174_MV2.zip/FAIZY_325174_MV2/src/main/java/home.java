package main.java;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class home {
	WebDriver dr;
	String base_xp="//div[@class='inventory_item'][";
	By xname,xprice,xbtn;
	
	public home(WebDriver dr) {
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	public String get_prod_name(int x) {
		xname=By.xpath(base_xp+x+"]//div[@class='inventory_item_name']");
		String name=dr.findElement(xname).getText();
		return name;
	}
	public void add_to_cart(int x) {
		xbtn=By.xpath(base_xp+x+"]//button");
		dr.findElement(xbtn).click();
	}
	public void click_cart() {
		dr.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a")).click();
	}
	
}
