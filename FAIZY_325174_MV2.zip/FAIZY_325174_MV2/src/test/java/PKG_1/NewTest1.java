package PKG_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import main.java.home;
import main.java.login;

public class NewTest1 {
	login lp;
	home hp;
	WebDriver dr;
	@BeforeClass
	public void beforeclass() {
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		dr=new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		lp=new login(dr);
		hp=new home(dr);
		
	}	
  @Test
  public void f() {
	 lp.login_page("standard_user", "secret_sauce");
	 hp.add_to_cart(1);
	 String k=hp.get_prod_name(1);
	 hp.click_cart();
	 String y=dr.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
	 SoftAssert sa=new SoftAssert();
	 sa.assertEquals(k, y); 
	 System.out.println("act_res1: "+k);
	 sa.assertAll();
  }
}
