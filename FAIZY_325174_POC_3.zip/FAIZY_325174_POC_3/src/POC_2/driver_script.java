package POC_2;

public class driver_script extends keyword_method {

		
		public static keyword k;
		public static selection s;

		public static void main(String[] args) {
			// TODO Auto-generated method stub

			int i,j=1;
			
			for(i=1;i<=3;i++) {
				
				s=new selection();
				s=read_TC_Selection_Sh(i);
				
				//System.out.println("TC  :  "+s.tid+ " Flag :  "+s.flag);
				
				if(s.flag.equals("Y")){
					
					while(true) {
					    
						k=new keyword();
						k=read_Keyword(j++);
						if((s.tc_id).equals(k.tcid)) {
							
						switch(k.keyword) {
						
						case "launchchrome":
							launchchrome(k.data);
							break;
							
						case "click_btn":
							//System.out.println(k.xp);
							click_btn(k.xpath);
							break;
							
						
						case "enter_txt":
							//System.out.println("Xpath  "+k.xp);
							enter_txt(k.xpath,k.data);
							break;
							
						case "Verify":
						   Verify(k.xpath,k.data);
						break;
							
						}//switch
						}//if
						else
							break;
						
						}//while
					
						
					}//flag if

					
				}//outer for loop
				
				
			}
			
			
			
		}




