package POC_2;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_operation {
	public static String fileName="Book1.xlsx";
	public static String key_sheet="Keyword";
	public static String Sel_sheet="TC_Selection_SH";
	public static XSSFSheet kw,sel;

	public String selection_sheet(String tc_id) {
		
	}
	
	
	
	
	
	public String excel_read(int row,int col) {
		File f=new File(fileName);
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh= wb.getSheet("KEYWORD");
		
		XSSFRow r=sh.getRow(row);
		XSSFCell c1=r.getCell(col);
		String tcid=c1.getStringCellValue();
		String flag=selection_sheet(tcid);
	   
	   
	   
	   
	   
	   
	
     public static set_sheet(String sheetName) {
		
		try {
		File f=new File(fileName);
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		 sh= wb.getSheet(sheetName);
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
     return sh;
     }
	
	
	
	public static keyword read_Keyword(int i) {
		kw=set_sheet(key_sheet);
		
		keyword k=new keyword();
		
		XSSFRow r=kw.getRow(i);
		
		XSSFCell c2=r.getCell(0);
		k.tcid=c2.getStringCellValue();
		
		XSSFCell c=r.getCell(3);
		k.keyword=c.getStringCellValue();
		
		
        XSSFCell c1=r.getCell(4);
		
		k.xpath=c1.getStringCellValue();
		
		k.data=r.getCell(5).getStringCellValue();
		
		return k;
	
	}
	
	
	public static selection read_TC_Selection_Sh(int i) {
		
		sel=set_sheet(Sel_sheet);
		selection s =new selection();
		
		
		XSSFRow r=sel.getRow(i);
		
		s.tc_id=r.getCell(0).getStringCellValue();    //reading test_)case id
		
		
		s.flag=r.getCell(1).getStringCellValue();     //reading flag
		
		XSSFCell c=r.getCell(2);
		s.no_of_steps=(int)c.getNumericCellValue();//read no of step
	
		
		return s;
		
	}

	
	
	
}
	
    

