package POC_2;

public class keyword {
	String tcid;
	int step_no;
	String keyword;
	String xpath;
	String data;
	String result;

}
