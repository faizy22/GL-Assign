package POC_2;

public class selection {
	
	public String tc_id;
	public String flag;
	public int no_of_steps;
	public String test_result;

}
