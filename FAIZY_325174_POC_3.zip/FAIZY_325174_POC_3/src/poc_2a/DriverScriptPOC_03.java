//poc.xlsx
package poc_2a;

import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.apache.log4j.Logger;

 

public class DriverScriptPOC_03 {
	
	int count=0;
	String fromExcel=null,fromWebsite=null;
	
	
public String read_excel_sheet1(int row,int col)
	{
	String cellValue = null;
	   try {
			File f=new File("poc.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("sheet1");
			
			XSSFRow r=sh.getRow(row);
			
			XSSFCell c=r.getCell(col);
			cellValue =c.getStringCellValue();
			 
			}
			
		catch(Exception e) {
 			e.printStackTrace();
		 }
	
		return cellValue ;
	}
	
	


public void enter_txt(String xp,String data,ChromeDriver cd) {
			 cd.findElement(By.xpath(xp)).sendKeys(data);
		}
		
		
 
public String verify(String testData,WebElement we)
		{
	        fromWebsite=we.getText();
			fromExcel=testData;
		    System.out.println("From Website:"+fromWebsite);
		    System.out.println("From Excel:"+fromExcel);
			if(fromExcel.equals(fromWebsite))
                   return "Pass";			 
            return "Fail";		 
		}


public WebElement ExplicitWait(String xp,WebDriverWait wd,WebElement we)
{
	
	 we=wd.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xp)));
	 return we;
}


 
public void printLog(String testResult) {
Logger log=Logger.getLogger("devpinoyLogger"); 
System.out.println("testREsult:"+testResult);
log.debug("Expected:"+fromExcel+"    "+"Actual:"+fromWebsite+"    "+"Result:"+testResult);

		}


public void click(String xp,ChromeDriver cd) {
			cd.findElement(By.xpath(xp)).click();
		}
		
		
public void launch(String url,ChromeDriver cd) {
 			cd.get(url);
		}
		
		
		
		
		
public String ExecuteKeyword(int start,int n){
		 String key,xpath,testData,testResult=null;
		 int r;
 		 
		 System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		 ChromeDriver cd=new ChromeDriver();
		 DriverScriptPOC_03 ds=new DriverScriptPOC_03();
		 WebDriverWait wd=new WebDriverWait(cd,20); 
		 WebElement we=null;
		 
		 
		 
		  
			 for(r=start;r<n;r++) {
				    //System.out.println("n="+n);
					key= ds.read_excel_sheet1(r,3);
					System.out.println("key:"+key);
					
					xpath=ds.read_excel_sheet1(r,4);                            //*[@id="LastName"]
					System.out.println("location:"+xpath);
					
					testData= ds.read_excel_sheet1(r,5);
					System.out.println("testData:"+testData);
 					 
					switch(key)
					{
					
					case "launch"        :ds.launch(xpath,cd);
					                      System.out.println("launch chrome");    
					                       break;
					
					case "click"         :ds.click(xpath,cd); 
					                      System.out.println("click btn");   
		                                  break;
					
					case "enter_text"    :ds.enter_txt(xpath,testData,cd); 
					                      System.out.println("enter text");
					                      break;                                   //*[@id="ConfirmPassword"]
					
					case "verify"        :testResult=ds.verify(testData,we);                 //*[@id="register-button"]
					                      System.out.println("captured verify testdResult="+testResult);
					                      break;
					
					case "log"           :ds.printLog(testResult);  
					                      System.out.println("log captured");
					                      break;
					                      
					case "wait"          :we=ds.ExplicitWait(xpath,wd,we);      
					                      break;
					 
					 
					}
					
					System.out.println("\n");
					
			 }
			 
			 return testResult;
			 
		 }





}
			 
		 
		 
		 
		
	   
 

 
