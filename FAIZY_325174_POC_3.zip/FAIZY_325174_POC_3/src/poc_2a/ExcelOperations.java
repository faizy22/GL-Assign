package poc_2a;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.sun.xml.internal.ws.encoding.soap.SOAP12Constants;

public class ExcelOperations  {
	 int start;
	 
	public void readExcel(String sheet,int row,ArrayList<Sheet2Details> arr)
	{
		Sheet2Details s=new Sheet2Details();
        DriverScriptPOC_03 d=new  DriverScriptPOC_03();
        Search se=new Search();
 		 
		try {
			File f=new File("poc.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet(sheet);
			
			XSSFRow r=sh.getRow(row);
			
			XSSFCell c0=r.getCell(0);
			s.tc_id=c0.getStringCellValue();
			
			XSSFCell c1=r.getCell(1);
			s.flag=c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(2);
			s.nos=(int)c2.getNumericCellValue();
			
			 
			
			if(s.flag.equals("Y")) {
				
				/*if(s.tc_id.equals("TC_33"))
				     start=1;
				else
					 start=6;
				s.result=d.ExecuteKeyword(start,s.nos+start);*/
				
				start=se.searchStartRow(s.tc_id);
			//	System.out.println("start="+start);
				s.result=d.ExecuteKeyword(start,s.nos+start);
				//System.out.println("result="+s.result);
				
			}
			
			else
				s.result="";
				
				
			
		}
		
		
		 catch(Exception e){
			 e.printStackTrace();
		 }
		
	
	System.out.println("row="+row+"    "+s.tc_id+"  "+s.flag+"   "+s.nos+"    "+s.result);
    arr.add(s);	
		
	}



	
	
public void writeExcel(String sheet, int row,Sheet2Details s) {
		
		try {
			File f=new File("poc.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet(sheet);
			
			XSSFRow r=sh.getRow(row);
			
			XSSFCell c3=r.createCell(3);
			//System.out.println("row="+row+"    "+s.tc_id+"  "+s.flag+"   "+s.nos+"    "+s.result);
			System.out.println();
			//System.out.println("inside write function result "+s.result);
			c3.setCellValue(s.result);
 			
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			}
			
		
catch(Exception e) {
			e.printStackTrace();
		}
 		
	}
public static void main(String[]args)
{
	
	ArrayList<Sheet2Details> arr=new ArrayList<Sheet2Details>();
	ExcelOperations e=new ExcelOperations();
    Search se=new Search();
	
	int i,n;
	n=se.getRowCount("Sheet2");
	
	System.out.println("n="+n);
	
	for(i=1;i<n;i++)
		e.readExcel("Sheet2",i,arr);
	
	
	
	
	int row=1;
	for(Sheet2Details s:arr)
	System.out.println(s.tc_id+"  "+s.flag+"   "+s.nos+"    "+s.result);
	
	for(Sheet2Details s:arr){
		e.writeExcel("Sheet2",row,s);
		System.out.println("row="+row+"  "+s.result);
          row++;
		
	}
		
	}
}