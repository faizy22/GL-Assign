package poc_2a;

import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class Search {
	
	public int searchStartRow(String tc_id)
	{
		
	String cellvalue=null;
	int n;
		try {
			File f=new File("poc.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			n=sh.getPhysicalNumberOfRows();
			
			for(int i=1;i<n;i++) {
			
			XSSFRow r=sh.getRow(i);
			
			XSSFCell c0=r.getCell(0);
			cellvalue=c0.getStringCellValue();
			if(cellvalue.equals(tc_id))
			    return i;
			}
			
}catch(Exception e) {
		e.printStackTrace();

}
	
	 
return -1;
	
	}
	
	
	
	
	
	public int getRowCount(String sheet) {
		
		int n=0;
		try {
			File f=new File("poc.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet(sheet);
			
		    n=sh.getPhysicalNumberOfRows();
	}catch(Exception e) {
		e.printStackTrace();
	}
		
	
	return n;
	}
	
	
	
	
}
