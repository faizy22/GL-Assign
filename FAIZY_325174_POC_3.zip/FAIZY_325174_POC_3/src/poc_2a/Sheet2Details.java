package poc_2a;

public class Sheet2Details {
	
	String tc_id,flag;
	String result;
	int nos;

}
