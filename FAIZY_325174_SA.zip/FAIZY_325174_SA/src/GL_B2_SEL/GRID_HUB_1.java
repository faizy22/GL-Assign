package GL_B2_SEL;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class GRID_HUB_1 {
	WebDriver dr;
	String autURL, nodeURL;
	
	@BeforeClass
	public void setup() throws MalformedURLException{
		autURL="https://www.facebook.com";
		nodeURL="http://192.168.0.114:5566/wd/hub";
		DesiredCapabilities cap= DesiredCapabilities.firefox();
		cap.setBrowserName("firefox");
		cap.setPlatform(Platform.WINDOWS);
		dr=new RemoteWebDriver(new URL(nodeURL), cap);
	}
	
	@Test
	public void t1() {
		dr.get("https://www.facebook.com");
	}
}
