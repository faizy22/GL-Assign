package HYBRID_FRAMEWORK;

public class login_test_data {
public String uid;
public String pwd;
}
