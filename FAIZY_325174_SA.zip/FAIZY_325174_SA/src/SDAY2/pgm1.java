package SDAY2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();	//launch the browser
		dr.get("https://www.facebook.com");
		dr.findElement(By.name("email")).sendKeys("9472820541");
		dr.findElement(By.name("pass")).sendKeys("9934808659");
		
		dr.findElement(By.id("loginbutton")).click();
		String s=dr.findElement(By.xpath("//*[@id=\"u_0_a\"]/div[1]/div[1]/div/a/span/span")).getText();
		if(s.equals("Subhajit")) {
			System.out.println("Successful");
		}else {
			System.out.println("Unsuccessful");
		}
		/*dr.findElement(By.id("email")).sendKeys("9934808659");
		dr.findElement(By.id("pass")).sendKeys("9472820541");*/
		//
		//dr.findElement(By.xpath("//*[@id=\"login_form\"]/table/tbody/tr[3]/td[2]/div/a")).click();
		//dr.findElement(By.xpath("//*[@id=\"u_0_a\"]/div[3]/a")).click();

		/*WebElement wel= dr.findElement(By.id("day"));
		Select sel1=new Select(wel);
		sel1.selectByVisibleText("12");
		WebElement wel1= dr.findElement(By.id("month"));
		Select sel2=new Select(wel1);
		sel2.selectByVisibleText("Jan");
		WebElement wel2= dr.findElement(By.id("year"));
		Select sel3=new Select(wel2);
		sel3.selectByVisibleText("1997");
		
		//Reading and returning title
		
		String title=dr.getTitle();
		System.out.println(title);*/
		
		//radio button selection using list
		
		/*List rb=dr.findElements(By.name("sex"));
		((WebElement)rb.get(1)).click();	//Typecasting list object(rb) to webelement to get the click functionality
		
		*/
		
		
		
	}

}
