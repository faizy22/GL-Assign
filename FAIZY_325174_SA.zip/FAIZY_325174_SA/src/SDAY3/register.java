package SDAY3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class register {
	public static registerdata test;
	public static registerdata readexcl() {
		registerdata da=new registerdata();
		
		
		try {
			File f=new File("C:\\Users\\faizy.mazhar\\Desktop\\Training\\register.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(1);
			XSSFCell c=r.getCell(0);
			da.fname=c.getStringCellValue();
			
			XSSFCell c1=r.getCell(1);
			da.lname=c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(2);
			da.email=c2.getStringCellValue();
			
			XSSFCell c3=r.getCell(3);
			da.gender=c3.getStringCellValue();
			
			XSSFCell c4=r.getCell(4);
			da.pass=c4.getStringCellValue();
			
			XSSFCell c5=r.getCell(5);
			da.conpass=c5.getStringCellValue();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return da;
		
	}
	public static void registration() {
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();	//launch the browser
		dr.get("http://demowebshop.tricentis.com");
		String title=dr.getTitle();
		if(title.equals("Demo Web Shop")) {
			dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
			String title1=dr.getTitle();
			if(title1.equals("Demo Web Shop. Register")) {
				
				dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys(test.fname);
				dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys(test.lname);
				dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(test.email);
				if(test.gender.equals("Male")) {
					
						dr.findElement(By.xpath("//*[@id=\"gender-male\"]")).click();
				}
				else {
					
						dr.findElement(By.xpath("//*[@id=\"gender-female\"]")).click();
				}
				dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(test.pass);
				dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys(test.conpass);
				dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
				String res=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
				if(res.equals(test.email)) {
					System.out.println("Registration Successful");
				}else {
					System.out.println("Registration Unsuccessful");
				}
			}
			else {
				System.out.println("Wrong WebPage");
			}
		}else {
			System.out.println("Wrong WebPage");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test=readexcl();
		registration();
		
	}

}
