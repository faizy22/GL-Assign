package SDAY3;

public class table {
	String name;
	String email;
	String password;
}
