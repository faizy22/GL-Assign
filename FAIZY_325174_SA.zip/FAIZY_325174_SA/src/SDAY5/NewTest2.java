package SDAY5;

import org.testng.annotations.Test;

import SDAY4.login_data;
import SDAY4.test_login;

public class NewTest2 {
	test_login loginob;
	login_data ldata,ldata_out;
  @Test
  public void t1() {
	  ldata=new login_data();
	  ldata_out=new login_data();
	  loginob=new test_login();
	  
	  ldata.uid="faizymazhar22@gmail.com";
	  ldata.pwd="faizy22";
	  ldata.exp_res1="SUCCESS";
	  
	  ldata_out=loginob.login(ldata);
	  System.out.println("ldata_out.act_res1: "+ldata_out.act_res1);
  }
}
