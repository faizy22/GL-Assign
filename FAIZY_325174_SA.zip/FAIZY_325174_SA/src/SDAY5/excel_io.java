package SDAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class excel_io {
	static ArrayList<login_data> data_al;
	public ArrayList<login_data> get_test_data() {
		
		ArrayList<login_data> ar=new ArrayList<login_data>();
		login_data da;
		
		String s=null;
		try {
			
			File f=new File("C:\\Users\\faizy.mazhar\\Desktop\\Training\\logincred.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			for(int r1=1;r1<=2;r1++) {
			login_data td=new login_data();
			XSSFRow r=sh.getRow(r1);
			XSSFCell c=r.getCell(0);
			td.uid=c.getStringCellValue();
			
			XSSFCell c2=r.getCell(1);
			td.pwd=c2.getStringCellValue();
			XSSFCell c3=r.getCell(2);
			td.exp_res1=c3.getStringCellValue();
			if(td.exp_res1.equals("FAILURE"))
			{
			XSSFCell c4=r.getCell(3);
			td.exp_em1=c4.getStringCellValue();
			XSSFCell c5=r.getCell(4);
			td.exp_em2=c5.getStringCellValue();
			
			}
			
			ar.add(td);
			}
		}
			
		  catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ar;
		
	}
	public void write_excel(ArrayList<login_data> dr) {
		File f=new File("C:\\Users\\faizy.mazhar\\Desktop\\Training\\logincred.xlsx");
		try {
			int r=1;
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			int row=1;
			for(login_data d:dr) {
			XSSFRow r1=sh.getRow(row);
			
			XSSFCell c1=r1.createCell(5);
			c1.setCellValue(d.act_res1);
			XSSFCell c2=r1.createCell(6);
			c2.setCellValue(d.act_em1);
			
			XSSFCell c3=r1.createCell(7);
			c3.setCellValue(d.act_em2);
			XSSFCell c5=r1.createCell(8);
			c5.setCellValue(d.status);
			
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			row++;
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
