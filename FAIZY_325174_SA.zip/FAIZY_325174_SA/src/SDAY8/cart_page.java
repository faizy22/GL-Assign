package SDAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class cart_page {

	 WebDriver dr;

	public cart_page(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	public String verify()
	{
		String s=dr.findElement(By.xpath("//div[@class=\"inventory_item_name\"]")).getText();
		System.out.println(s);
		return s;
	}
	
	

}
