package SDAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class home_page {
	WebDriver dr;
	String base_xp="//div[@class=\'inventory_item\'][";
	By xp;
	
	public home_page(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	public void add_to_cart(int n)
	{
		//   //div[@class="inventory_item"][1]//button
		xp=By.xpath(base_xp+n+"]//button");
		dr.findElement(xp).click();
		
		
	}
	

	public void click_cart() {
		// TODO Auto-generated method stub
		dr.findElement(By.xpath("//a[@href=\'./cart.html\']")).click();
		
	}
	
	
	
	

}
