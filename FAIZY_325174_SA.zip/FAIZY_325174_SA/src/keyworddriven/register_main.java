package keyworddriven;

import org.openqa.selenium.WebDriver;

public class register_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String kw,loc,td;
		WebDriver dr=null;
		webelement we=new webelement(dr);
		register_excel ex=new register_excel();
		for(int r=0;r<=15;r++)
		{
		  kw=ex.readexcl(r, 1);
		  loc=ex.readexcl(r, 2);
		  td=ex.readexcl(r, 3);
		  switch(kw)
		  {
		  case "launchchrome" :
			  we.launchChrome(td);
			  break;
			  
		  case "enter_txt" :
			  we.entertext(loc, td);
			  break;
			  
		  case "radio" :
			  we.radio(loc,td);
			  break;
			  
		  case "verify" :
			  boolean a=we.verify(loc,td);
			  ex.writeexcel(r, 4, a);
			  break;
			  
		  case "click_btn":
			  we.click(loc);
			  break;
			
			  
			  
			  
		  }

		}
		

	}

}
