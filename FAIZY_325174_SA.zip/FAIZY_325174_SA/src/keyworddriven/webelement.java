package keyworddriven;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class webelement {

	WebDriver dr;

	webelement(WebDriver dr)
	{
		this.dr=dr;
	}



	public void entertext(String xp,String data)
	{
		dr.findElement(By.xpath(xp)).sendKeys(data);
	}



	public void radio(String xp,String data)
	{
		if(data.equals("Male"))
		{
			dr.findElement(By.xpath(xp)).click();
		}
		else if(data.equals("Female"))
		{
			dr.findElement(By.xpath(xp)).click();;

		}
	}


	public void click(String xp)
	{
		dr.findElement(By.xpath(xp)).click();

	}


	public boolean verify(String xp,String data)
	{
		boolean b=false;
		String s=dr.findElement(By.xpath(xp)).getText();
		
		if(s.equals(data))
		{
			System.out.println("Successfully registered and logged in");
			b=true;
		}
		else
		{
			System.out.println("Registration not successful");

		}
		return b;

	}

	public void closebr()
	{
		dr.close();
	}


	public void launchChrome(String url)
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr=new ChromeDriver();
		dr.get(url);
	}


}
